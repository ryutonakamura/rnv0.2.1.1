これはウイルスです。セキュリティソフトでスキャンしても脅威にはなりません。）virus(danger).batまたはvirus(safety).batを実行してください。そのほか、ryutonakamura29@gmail.comにお問い合わせください。

※フォルダーの中のbatファイルに変更を加えないでください。ウイルスが機能しなくなる可能性があります。またvirus(danger).batは危険でvirus(safety).batは安全です。